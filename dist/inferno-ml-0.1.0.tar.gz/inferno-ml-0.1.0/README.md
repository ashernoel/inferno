# inferno
Accelerating Inference for CNN's and LLM's through Transferable Architectures and Task-Specific Pruning
